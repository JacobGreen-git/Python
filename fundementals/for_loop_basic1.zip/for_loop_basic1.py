for i in range(0, 151):
    print(i)



for i in range(5, 1000, 5):
    print(i)



for x in range(0,101):
    if x % 5 == 0:{
        print("Coding")
    }
    else:{
        print(x)
    }



sum = 0
for x in range(1, 500000, 2):
    sum = sum + x
print(sum)



for x in range(2080,0,-4):
    print(x)



lowNum = 1
highNum = 25
mult = 3
for x in range(lowNum, highNum, mult):
    print(x)