from flask_app_Users import app
from flask_app_Users.controllers import users_controller


if __name__=="__main__":
    app.run(debug=True)